/*Lab4: Your implementation of lab4*/
